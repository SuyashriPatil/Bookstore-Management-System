package com.bookstore.config;

import io.swagger.v3.oas.models.*;
import io.swagger.v3.oas.models.info.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI bookstoreOpenAPI() {

        return new OpenAPI()
                .info(
                        new Info()
                                .title(
                                        "Bookstore Management API")
                                .version("1.0")
                                .description(
                                        "Spring Boot Bookstore Management System")
                );
    }
}