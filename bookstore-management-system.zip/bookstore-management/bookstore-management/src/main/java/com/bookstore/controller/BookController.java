package com.bookstore.controller;

import com.bookstore.model.Book;
import com.bookstore.service.BookService;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books")
@CrossOrigin("*")
public class BookController {

    private final BookService service;

    public BookController(BookService service) {
        this.service = service;
    }

    @PostMapping
    public Book saveBook(
            @RequestBody Book book) {

        return service.save(book);
    }

    @GetMapping
    public List<Book> getAllBooks() {

        return service.getAllBooks();
    }

    @GetMapping("/{id}")
    public Book getBook(
            @PathVariable Long id) {

        return service.getBook(id);
    }

    @DeleteMapping("/{id}")
    public String deleteBook(
            @PathVariable Long id) {

        service.deleteBook(id);

        return "Book Deleted Successfully";
    }

    @GetMapping("/search")
    public Page<Book> searchBooks(

            @RequestParam String title,

            @RequestParam(defaultValue = "0")
            int page,

            @RequestParam(defaultValue = "5")
            int size) {

        return service.searchBooks(
                title,
                page,
                size);
    }
}