package com.bookstore.controller;

import com.bookstore.dto.OrderRequest;
import com.bookstore.model.Order;
import com.bookstore.service.OrderService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin("*")
public class OrderController {

    private final OrderService service;

    public OrderController(OrderService service) {
        this.service = service;
    }

    @PostMapping
    public Order placeOrder(
            @RequestBody OrderRequest request) {

        return service.placeOrder(request);
    }

    @GetMapping
    public List<Order> getAllOrders() {

        return service.getAllOrders();
    }
}