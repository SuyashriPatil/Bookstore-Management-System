package com.bookstore.dto;

import lombok.Data;

import java.util.List;

@Data
public class OrderRequest {

    private String customerName;

    private String email;

    private List<Long> bookIds;
}