package com.bookstore.model;

public enum OrderStatus {

    PENDING,
    SHIPPED,
    DELIVERED
}
