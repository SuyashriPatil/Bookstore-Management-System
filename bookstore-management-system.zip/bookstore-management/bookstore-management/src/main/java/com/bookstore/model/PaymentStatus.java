package com.bookstore.model;

public enum PaymentStatus {

    PENDING,
    PAID
}