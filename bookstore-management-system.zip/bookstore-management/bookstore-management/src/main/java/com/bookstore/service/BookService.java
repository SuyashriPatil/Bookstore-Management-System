package com.bookstore.service;

import com.bookstore.model.Book;
import com.bookstore.repository.BookRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    private final BookRepository repository;

    public BookService(BookRepository repository) {
        this.repository = repository;
    }

    public Book save(Book book) {
        return repository.save(book);
    }

    public List<Book> getAllBooks() {
        return repository.findAll();
    }

    public Book getBook(Long id) {
        return repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Book Not Found"));
    }

    public void deleteBook(Long id) {
        repository.deleteById(id);
    }

    public Page<Book> searchBooks(
            String title,
            int page,
            int size) {

        return repository.findByTitleContainingIgnoreCase(
                title,
                PageRequest.of(page, size)
        );
    }
}