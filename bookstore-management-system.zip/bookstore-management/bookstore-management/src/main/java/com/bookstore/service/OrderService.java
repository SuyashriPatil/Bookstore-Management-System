package com.bookstore.service;

import com.bookstore.dto.OrderRequest;
import com.bookstore.model.*;
import com.bookstore.repository.BookRepository;
import com.bookstore.repository.OrderRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final BookRepository bookRepository;

    public OrderService(OrderRepository orderRepository,
                        BookRepository bookRepository) {

        this.orderRepository = orderRepository;
        this.bookRepository = bookRepository;
    }

    public Order placeOrder(OrderRequest request) {

        List<OrderItem> items = new ArrayList<>();

        double total = 0;

        for (Long id : request.getBookIds()) {

            Book book = bookRepository.findById(id)
                    .orElseThrow(() ->
                            new RuntimeException("Book Not Found"));

            OrderItem item = OrderItem.builder()
                    .book(book)
                    .quantity(1)
                    .totalPrice(book.getPrice())
                    .build();

            items.add(item);

            total += book.getPrice();
        }

        Order order = Order.builder()
                .customerName(request.getCustomerName())
                .email(request.getEmail())
                .items(items)
                .totalAmount(total)
                .orderStatus(OrderStatus.PENDING)
                .paymentStatus(PaymentStatus.PENDING)
                .build();

        return orderRepository.save(order);
    }

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }
}